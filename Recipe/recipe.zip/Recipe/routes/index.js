
// bsassam and MA
var express = require('express');
var router = express.Router();
var fs = require("fs");



console.log("\n *START* \n");
var content = fs.readFileSync("resipeObject.json");
var listr = JSON.parse(content);
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('fun-Dishes');
});

/* GET about page. */
router.get('/about', function(req, res, next) {
  res.render('About');
});

// login
router.get('/login', function(req, res, next) {
  res.render('login');
});
// login submit
router.post('/login', function(req, res, next) {
	
	if(req.body.Username == "admin")
			if(req.body.Password=== "admin")
				return res.redirect("/admin/recipie")

	var logged = false
	data = fs.readFileSync('users.json')
     
    json = JSON.parse(data); 
    for(var i =0 ;i < json.length;i +=1){
		if(json[i]["username"] == req.body.Username){
			if(json[i]["password"]=== req.body.Password){
				logged =true
				
			}
		}
	}
    if(logged)
    res.send("loggedin")
	else
  	res.send('logging failed');    
});
// signup
router.get('/signup', function(req, res, next) {
  res.render('signup');
});
// submitted signup
router.post('/signup', function(req, res, next) {
	var user = {
		username: req.body.Username, 
		email:req.body.Email , 
		password:req.body.Password
	}
	data = fs.readFileSync('users.json')
    obj = JSON.parse(data); 
    obj.push(user);
    var json = JSON.stringify(obj); 
    fs.writeFile('users.json', json); 
  	res.redirect('login')
});
// gallery all
router.get('/recipie/all',function(req,res,next){
	res.render('recipies',{"recps":listr})
});
// gallery filtered
router.get('/recipie/:qry',function(req,res,next){
	var newlist = [];
	listr.forEach(function(dish){
		if(dish["Title"].toLowerCase().indexOf(req.params.qry.toLowerCase()) > -1)//req.params["qry"])
			newlist.push(dish)
	});
	res.render('recipies',{"recps":newlist})
});
// search request
router.post('/recipie/filter',function(req,res,next){	
	res.redirect('/recipie/'+req.body.qry)
});

// details
router.get('/recipie/details/:id',function(req,res,next){
	listr.forEach(function(x){
		if(x["Id"] === req.params.id){
			return res.render('details',{"dish":x})
		}
	})
	res.send("Not found")
});


// Admin
router.get('/admin/recipie',function(req,res,next){
	res.render('admin' , {"rcps":listr})
});
// add
router.get('/admin/recipie/add',function(req,res,next){
	res.render("addRecp")
});
router.post('/admin/recipie/add',function(req,res,next){
	var dish = {
		"Id":req.body.Title +Math.floor(Math.random() * Math.floor(1000)),
        "Title":req.body.Title,
        "Description":req.body.Description,
        "Ingredients":req.body.Ingredients.split("\n"),
 
        "Time":{
            "Prep Time": req.body.prepTime,
            "Cook Time": req.body.cookTime,
            "Total Time": req.body.totalTime
        },
        "LevelOfDiffculty": req.body.Diffculty,

        "NutritionalFacts":req.body.NutritionalFacts.split("\n"),
        "Rference": req.body.refrences.split("\n"),
        "image": req.body.image.split("\n")
	}
	listr.push(dish)
	res.redirect("/admin/recipie")
});
// edit 
router.get('/admin/recipie/edit/:id',function(req,res,next){
	i =0
	for(i=0;i < listr.length; i+=1){
		if(listr[i]['Id'] == req.params.id)
			break;
	}
	res.render('updateRecp' ,{'dish': listr[i]})
});

router.post('/admin/recipie/update/:id',function(req,res,next){
	i =0
	for(i=0;i < listr.length; i+=1){
		if(listr[i]['Id'] == req.params.id)
			break;
	}
	var dish = {
		"Id":req.body.Title +Math.floor(Math.random ()),
        "Title":req.body.Title,
        "Description":req.body.Description,
        "Ingredients":req.body.Ingredients.split("\n"),
 
        "Time":{
            "Prep Time": req.body.prepTime,
            "Cook Time": req.body.cookTime,
            "Total Time": req.body.totalTime
        },
        "LevelOfDiffculty": req.body.Diffculty,

        "NutritionalFacts":req.body.NutritionalFacts.split("\n"),
        "Rference": req.body.refrences.split("\n"),
        "image": req.body.image.split("\n")
	}
	listr[i] = dish
	res.redirect('/admin/recipie/')
});


router.get('/admin/recipie/delete/:id',function(req,res,next){
	var i = 0
	listr.forEach(function(dish){
		if(dish["Id"] == req.params.id){
			return;
		}
		i++;
	})
	delete listr[i]	
	console.log(listr)
	//fs.writeFile("resipeObject.json", listr)
	res.redirect("/admin/recipie")
});
module.exports = router;

